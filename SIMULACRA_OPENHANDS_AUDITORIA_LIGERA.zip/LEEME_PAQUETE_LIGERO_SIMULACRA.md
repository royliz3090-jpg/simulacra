# SIMULACRA — paquete ligero para OpenHands

Este paquete evita el límite de 3 MB **de archivos adjuntos sumados** de OpenHands.

**No incluye core.assets, core.binary, es-latam.fs ni extracción JSONL de 4,4 MB.**
Los tres binarios ya están en `dist/` del repositorio; compara los SHA-256 de `MANIFIESTO_SHA256.txt` para saber si corresponden a la compilación auditada. Si difieren, reextrae y reubica antes de aplicar correcciones.

Lee `PROMPT_OPENHANDS_SIMULACRA_LIGERO.md` y luego los informes y JSON adjuntos. `SIMULACRA_V2_FIXES_POR_OBJETO.json` y la auditoría de los 25 minijuegos contienen propuestas, no modificaciones aplicadas. Prueba la mecánica antes de integrar y no uses reemplazos ciegos.

Si el límite sigue apareciendo, retira otros adjuntos de la conversación de OpenHands: el máximo incluye la suma de los archivos presentes, no solo el último que seleccionaste. También puedes copiar el texto del prompt directamente sin adjuntar este ZIP.
