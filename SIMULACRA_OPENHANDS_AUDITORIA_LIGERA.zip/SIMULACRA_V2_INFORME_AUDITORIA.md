# SIMULACRA — Auditoría de los binarios recibidos

## Alcance

Se inspeccionaron directamente los archivos cargados `core(2).assets`, `core(2).binary` y `es-latam (1).fs`, sin ejecutarlos ni alterar los originales. La extracción usa la estructura Mass FileSystem, objetos Kryo y descompresión zlib, incluyendo objetos comprimidos; las cadenas Java se leyeron de clases AES/CTR en el contenedor KCB1. El análisis es estático; no sustituye jugar cada rama narrativa.

## Integridad

- Los archivos `en-us.fs` y `es-latam.fs` dentro de `core.assets` contienen **28.315 objetos cada uno** y **30.877 cadenas detectables cada uno** (incluyen código, recursos, marcas, nombres y diálogos).
- Las **30.877 parejas se pudieron alinear por objeto e índice**, con igual cantidad de cadenas en cada objeto.
- Hay **1.746 objetos comprimidos por idioma**.
- `es-latam (1).fs` es **idéntico** al miembro `es-latam.fs` de `core.assets` (SHA-256: `943dffe911c7c0744b1d25354f90efc8d1636999cfa290e2260a56c37f288dc5`).
- Se reconoció `core.binary` como KCB1 de **1.105 entradas de clases**, con 2.300.768 bytes de datos; se extrajeron de forma estática **235 clases referenciadas** desde las raíces conocidas, entre ellas `game27.gbeslatam.GBESLATAM`.
- Comparado con el archivo `LOTE2.md` anterior, las **59 cadenas marcadas como posible truncamiento** y las **2 marcadas por contenido faltante** ya tienen contenido español diferente del exportado antiguamente. Esta comprobación no garantiza su calidad narrativa.

## Resultados de calidad

- No se encontraron grandes fragmentos de inglés en la sección española mediante la heurística de palabras inglesas empleada, pero eso NO prueba cobertura total: las frases cortas, textos de interfaz, títulos y recursos Java requieren otro procedimiento.
- **1 pareja presenta distinta cantidad de saltos de línea**, un correo de Anna a Ed: el español omite `I think it works!` ("¡Creo que funciona!").
- **2 textos de `Anna` se transformaron en `Ana`** (objetos 18919 y 19400); **1 de `Taylor` en `taylor`** (19176).
- `Mom` se encuentra como `Mom`, `Mam` y `Mamá`. La forma truncada `Mam` (objeto 510) se incluye para confirmar contexto antes de aplicar.
- Quedan preguntas con puntuación defectuosa y traducciones incompletas, como `How?` -> `Eh?`, `Who are you, exactly?` -> `Quien eres, ?`, o `How do I find her?` -> `Como encuentro?`. El archivo de parches localiza cada aparición por objeto y ordinal de cadena.
- Los nombres de recursos `Camera`, `Chat Images`, `Voicemail` y otros siguen en inglés; no se deben corregir sin verificar si son etiquetas visibles o claves internas.
- Se verificaron **0 diferencias de marcadores protegidos** en la comparación global EN/ES según la expresión de control usada; otras claves no reconocidas automáticamente aún deben comprobarse manualmente.

## Textos de interfaz todavía en inglés dentro de core.binary

Se identificaron instrucciones Java que insertan directamente estas cadenas en componentes visuales, sin reemplazo español junto a la instrucción: 

- `game27.gb.GBNotification`: `EXIT TO MAIN MENU`, `Iris Memos`, confirmación de salida al menú, `Pending`, `Failed`, `Memo`, `Completed` y `SAVED`.
- `game27.gb.GBMainMenu`: `OPTIONS`, mensaje de ayuda de SIMULACRA y aviso de modo `BEGIN+`. Otras cadenas como el aviso de reiniciar ya llaman a un selector de idioma y no deben tratarse igual.
- `game27.gb.GBCreditsMenu`: encabezados y agradecimientos en inglés como `GAME DESIGN`, `DEVELOPMENT`, `CAST`, `SPECIAL THANKS` y `Thank you`.

Son **candidatos de alta relevancia** para corregir en el código fuente y reconstruir `core.binary` (nunca mediante reemplazo directo de bytes). La ejecución efectiva de cada pantalla y la eventual sustitución adicional en tiempo de ejecución siguen sin verificarse.

## Entregables

1. `SIMULACRA_V2_EXTRACCION_EN_ES.jsonl`: los 30.877 pares EN/ES con índices de objeto, orden de cadena, indicador de compresión y URI cuando es identificable. No supone que todos sean diálogos.
2. `SIMULACRA_V2_FIXES_POR_OBJETO.json`: **52 ediciones propuestas por ubicación exacta** del recurso `.fs`. Incluye algunas correcciones contextuales que requieren inspección visual.
3. `SIMULACRA_V2_PENDIENTES_JAVA.json`: **28 cadenas candidatas en Java** y traducciones propuestas, sin tratar estos textos como automáticamente editables.

## Uso recomendado con OpenHands

1. Trabajar en rama nueva y conservar copias exactas de los tres archivos originales.
2. Comparar el archivo `FIXES_POR_OBJETO.json` con cada cadena y su ubicación en el objeto decodificado antes de escribir. Nunca aplicar cambios globales para `Anna`, `Taylor` o `Mom`.
3. Aplicar las traducciones en las clases Java al código fuente correspondiente; inspeccionar rutas de ejecución y comprobar la selección del idioma para evitar convertir el inglés de los otros idiomas.
4. Reconstruir archivos `.fs` con offsets Kryo/zlib actualizados y volver a empaquetar `core.assets`. Validar firma KCB1, compresión, CRC y todos los nombres protegidos al generar `core.binary`.
5. Ejecutar el juego y recorrer menús, notificaciones, créditos, diálogos, llamadas, correos, Spark, Jabbr, rompecabezas, rutas alternativas y finales. Reextraer y comparar.
6. **No declarar el 100 %** hasta que estas pruebas de funcionamiento y localización hayan pasado.

No se modificaron los archivos originales ni se hicieron commits en GitHub.
