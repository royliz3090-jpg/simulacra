# OpenHands — cierre de localización SIMULACRA V2 (paquete ligero)

El ZIP adjunto contiene únicamente auditorías, correcciones propuestas y un manifiesto de hashes. **NO contiene los binarios** porque esos archivos ya están presentes en `dist/` del repositorio. No pidas ni descargues un segundo adjunto grande.

## 1. Preparación

1. Abre el repositorio `royliz3090-jpg/simulacra` que ya está en este workspace. Ejecuta `git status`, identifica la rama y el último commit, actualiza las referencias y lee `AGENTS.md` si existe, `docs/ESTADO_TRADUCCION.md` (en especial los apartados recientes) y `docs/ARQUITECTURA_IDIOMA.md`.
2. Comprueba que existen `dist/core.assets`, `dist/core.binary` y `dist/es-latam.fs`. Lee `MANIFIESTO_SHA256.txt` para comparar sus hashes con los de la versión auditada. Si son diferentes, NO utilices índices de objeto sin antes reextraer y reubicar las cadenas, y NO sobrescribas archivos del repo con adjuntos antiguos.
3. Conserva todos los commits ya realizados. Crea una rama nueva a partir del estado MÁS RECIENTE de la rama de traducción, sin retroceder a una versión anterior. No alteres `main` ni hagas merge sin autorización.

## 2. Correcciones de los binarios

Revisa íntegramente:
- `SIMULACRA_V2_FIXES_POR_OBJETO.json` (52 propuestas de cambios en objetos y cadenas).
- `SIMULACRA_V2_PENDIENTES_JAVA.json` (28 textos en clases Java que requieren verificar la ruta de ejecución y su visibilidad para el jugador).
- `SIMULACRA_MINIJUEGOS_RESTPHRASE_AUDITORIA.json` (25 minijuegos de restaurar frases, con propuestas de sincronización entre fichas y texto restaurado).
- `SIMULACRA_MINIJUEGO_GREG1_FIXES.json` (tres correcciones de alta confianza del minijuego donde la frase termina en «se pasó de la raya»).
- Ambos informes `.md` de la auditoría.

Las listas incluyen **propuestas, no cambios ya aplicados**. Antes de modificar cada ubicación compara `en`, `es_actual`, el recurso, el índice y el contexto contra el binario ACTUAL. Una ubicación desplazada debe localizarse de nuevo. Nunca hacer reemplazos globales de palabras como `Anna`, `Mom`, `Taylor`, `line` o `phone`. No inventar traducciones ni alterar valores internos.

## 3. Prioridad: minijuegos

Todos los minijuegos `content/restphrase/*` deben ser consistentes: la frase que se arma con las fichas y el mensaje que se muestra al completarla deben decir lo mismo en español natural. Preserva número de fichas, orden de la solución, marcas de corrupción intencionales y lógica de activación. Casos conocidos: Greg (línea/raya), James (`position`), Ashley (`phone teléfono`), Taylor (frase incoherente), Greg (`casi` duplicado). Para las otras propuestas, validar los textos y su ruta antes de aplicarlas. En particular, el URI `james5` puede reutilizarse en contextos diferentes.

## 4. Reconstrucción y QA

- Implementa cambios mediante los scripts del repositorio para Kryo, índices, longitudes y objetos zlib. Para Java utiliza fuentes/parches y reconstrucción; jamás altera directamente bytes cifrados de `core.binary`.
- Conserva los miembros del ZIP, objetos, claves, triggers, placeholders `#state:...#`, `__LINK...`, tags `[HANDLE]`, rutas `corrupted://` y nombres propios.
- Reexporta y compara EN/ES, verifica conteos, hashes y que no surjan cadenas dañadas. Prueba rompecabezas durante y después de completarse, rutas alternativas y demás textos de interfaz.
- Si no puedes iniciar el juego en Wine, declara que solo verificaste estáticamente. La frase «sin incidencias a nivel de archivo» NO es equivalente a una verificación visual 100 %: se han encontrado inconsistencias reales después de esos chequeos.

## 5. Entrega

Haz commit y push de cambios verificables. Crea PR contra la rama de traducción correspondiente, sin fusionarlo. Devuelve: tabla por corrección (aplicada/omitida y motivo), pruebas realizadas y no realizadas, hashes y lista priorizada de pendientes. No anuncies un 100 % de traducción sin una revisión jugable integral.
