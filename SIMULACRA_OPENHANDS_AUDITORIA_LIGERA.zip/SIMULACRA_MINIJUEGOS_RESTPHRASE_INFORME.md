# SIMULACRA — Auditoría de minijuegos de restauración de frases

## Conclusión

* Se localizaron **25 recursos `content/restphrase/*`** que contienen las piezas de texto de los minijuegos.
* De ellos, **24 tienen mensaje restaurado correspondiente** en `corrupted://content/restphrase/*`.
* Los **24** presentan diferencias de redacción al reconstruir la frase y compararla con su mensaje restaurado (comparación insensible a acentos, mayúsculas y puntuación). **No todas son errores**: algunas son estilizaciones deliberadas o equivalencias de significado.
* El recurso `emailmurv1` no tiene mensaje restaurado con ese prefijo; necesita comprobación visual.
* Este informe proviene de los archivos adjuntos `core(2).assets` y `es-latam (1).fs`, extrayendo sus objetos. **No se ha probado el juego ni modificado ningún binario**.

## Hallazgos prioritarios

1. `greg1`: objeto de fragmentos 20033, índices 5 y 8 (`salió` → `pasó`, `línea` → `raya`); objeto de mensaje restaurado 6514 (añadir tildes).
2. `james2`: un fragmento se muestra literalmente como `position`, aunque el mensaje restaurado dice «puesto».
3. `ashley1`: los fragmentos reconstruyen «Así que le tomé phone teléfono...», duplicando el teléfono y dejando inglés.
4. `taylor1`: aparece «¿Reírse?» donde debe decir «lástima?», por el sentido de *pity laugh*.
5. `gregrc2`: aparece dos veces la palabra «casi» y signos de exclamación colocados en medio de la frase.
6. `jamesh10`: el minijuego dice «¿Ya has encontrado a ella?» y el mensaje restaurado tiene otra redacción.
7. `jamesh11`: aparece «tú tienes que ¡¡¡Apúrate!!!», que no forma una oración correcta.

## Tabla completa de los 25 recursos

| Recurso | Piezas en el minijuego (actual) | Mensaje restaurado (actual) | Frase sugerida |
|---|---|---|---|
| `jamesh10` | ¿Ya has encontrado a ella? | Ya La HaS hAlLaDo? | ¿Ya la has podido encontrar? |
| `jamesh12` | La respuesta está en Spark. | La ReSpUeStA eN sPaRk. | La respuesta está en Spark. |
| `jamesh11` | Ella se está quedando sin tiempo, tú tienes que ¡¡¡Apúrate!!! | Se Le AcAbA eL tIeMpO, aPrEsUrAtE!!! | Ella se está quedando sin tiempo. ¡Tienes que apresurarte ya! |
| `jamesh13` | eLLA vA cOMPARTIR mI dESTINO | CoMpArTiRa Mi DeStInO | Ella correrá la misma suerte |
| `gregrc2` | Tú me engañaste y casi, casi la dejas ¡Embarazada! | Me enganaste y casi la dejas embarazada! | Tú me fuiste infiel y casi la dejas embarazada! |
| `taylor1` | Vamos, ¿ni siquiera una risa de ¿Reírse? | Vamos, ni una risa de lastima? | Vamos, ¿ni siquiera una risa de lástima? |
| `jamesh5` | ¡Tú debes de haberlo visto! | yA lO vIsTe! | ¡Tú tienes que haberlo visto! |
| `jamesh4` | Tú debes resistir sus palabras | ReSiStE sUs PaLaBrAs | Tú debes resistir sus palabras |
| `jamesh7` | Ella se irá muy pronto | ElLa Se IrA pRoNtO | Ella se irá muy pronto |
| `gregrc1` | ¿Quién diablos es esta Yolanda? | Quien es Yolanda? | ¿Quién diablos es esa Yolanda? |
| `jamesh6` | Tú no eres Anna | Tu No ErEs AnNaAa | Tú no eres Anna |
| `jamesh1` | ¿Estás a salvo? | EsTaS bIeN? | ¿Estás a salvo? |
| `jamesh3` | tú lo oirás muy pronto | PrOnTo Lo OiRaS | Tú lo oirás muy pronto |
| `jamesh2` | Tú necesitas aprender a ignorar eso | TiEnEs qUe IgNoRaRlO | Tú tienes que hacer oídos sordos |
| `james1` | Soy redactor, hago sonar mejor las cosas malas de lo que parecen | Soy redactor, hago que lo malo suene mejor de lo que es. | Soy redactor, hago que lo malo suene mejor de lo que es. |
| `james2` | Mi position en Phresh Ideas aún sigue libre | Mi puesto en Phresh Ideas sigue libre | Mi puesto en Phresh Ideas aún está disponible |
| `james3` | Tienes un talento antinatural para adivinar toda mi historia | Tienes un talento raro para adivinar mi historia | Tienes un talento inquietante para adivinar toda mi historia |
| `james4` | Yo emparejé con esta chica llamada Cassie, también conocida como @keepingitcassie | Hice match con Cassie, tambien conocida como @keepingitcassie | Hice match con una chica llamada Cassie, también conocida como @keepingitcassie |
| `james5` | Encuéntrame este fin de semana y te muestro | Nos vemos el finde y te muestro | Quedemos este fin de semana y te muestro |
| `ashleyrc1` | YO TE VOY A HACER TU PERFIL | TE HARE TU PERFIL | YO TE VOY A HACER TU PERFIL |
| `greg1` | Tú eres el que se salió de la línea | Tu eres el que se paso de la raya | Tú eres el que se pasó de la raya |
| `emailmurv1` | Dime tu talla de cuerpo y yo te elegiré el vestido perfecto para ti. | No localizado | Dime tu talla de ropa y yo te elegiré el vestido perfecto para ti. |
| `ashley1` | Así que le tomé phone teléfono y se lo mostré | Le quite el telefono y se lo mostre. | Así que le quité su teléfono y se lo mostré. |
| `jamesh9` | Encuéntrame y tú la vas a encontrar | BuScAmE y La HaLLaRaS | Encuéntrame y tú la vas a encontrar |
| `jamesh8` | No puedo recordar | No ReCuErDo | No puedo recordar |

## Recomendaciones de implementación para OpenHands

1. Crear una rama específica y conservar copias verificables de los binarios originales. NO aplicar las 25 propuestas automáticamente.
2. Inspeccionar las clases del minijuego de reconstrucción para verificar si el orden del puzzle depende de índices o de comparar literalmente el texto de los fragmentos. Mantener la misma cantidad y orden original de piezas; no romper el algoritmo de victoria.
3. Aplicar primero las tres ediciones de alta confianza de `SIMULACRA_MINIJUEGO_GREG1_FIXES.json`, verificando el texto actual de cada objeto antes de reemplazarlo.
4. Revisar las 25 propuestas del JSON por escena y confirmar las variantes de personaje. Para mensajes `jamesh*`, **conservar el efecto de mayúsculas/minúsculas erráticas** que simula corrupción; no borrarlo a ciegas al sincronizar las frases.
5. En `james5`, la ruta `corrupted://content/restphrase/james5` se usa también para muchos mensajes diferentes. Editar únicamente el que corresponde al puzzle principal cuyo original completo es *Meet me this weekend and I’ll show ya*.
6. Preservar `content/restphrase/...`, `corrupted://...=`, las URLs, nombres de personaje y marcadores internos. Los cambios deben hacerse por **objeto + índice de cadena**, no por palabras globales.
7. Usar el editor compatible con objetos comprimidos y no comprimidos; recalcular longitudes y offsets de los bloques cuando cambien los bytes UTF-8.
8. Reextraer cada frase del resultado compilado y verificar el orden completo, la semántica y la visualización durante y después del minijuego. Probar guardado, recuperación y todos los casos de restauración.
9. Validar que no haya textos ingleses accidentales como `position` o `phone` dentro de las piezas, salvo términos de marca realmente necesarios.
10. Solo después de las pruebas, considerar el problema resuelto. La paridad en el archivo no reemplaza las pruebas de interfaz.

**Nota:** Las frases canónicas propuestas son sugerencias de revisión, no sustituciones binarias listas para aplicar automáticamente. El archivo de Greg contiene únicamente 3 cambios específicos confirmados en los recursos.
